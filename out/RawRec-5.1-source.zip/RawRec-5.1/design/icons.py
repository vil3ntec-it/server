#!/usr/bin/env python3
"""RawRec 1.5 icon set: one source for the Android vectors and the HTML preview.

Every icon sits on a 24 x 24 grid, drawn with a 1.75 stroke, round caps and round joins
(solid media glyphs use the same weight as a rounded outline). Run from the repo root:
    python3 design/icons.py            # writes app/src/main/res/drawable/ic_*.xml
It also refreshes the icon block of design/preview.html (between ICONS-BEGIN / ICONS-END), so the
preview always draws the app's real icons.
"""
import json, math, os, sys

SW = 1.75
f = lambda v: ('%.2f' % v).rstrip('0').rstrip('.')


def C(cx, cy, r):
    return f"M{f(cx - r)},{f(cy)}a{f(r)},{f(r)} 0 1,0 {f(2 * r)},0a{f(r)},{f(r)} 0 1,0 {f(-2 * r)},0z"


def R(x, y, w, h, r):
    return (f"M{f(x + r)},{f(y)}h{f(w - 2 * r)}a{f(r)},{f(r)} 0 0 1 {f(r)},{f(r)}v{f(h - 2 * r)}"
            f"a{f(r)},{f(r)} 0 0 1 {f(-r)},{f(r)}h{f(-(w - 2 * r))}a{f(r)},{f(r)} 0 0 1 {f(-r)},{f(-r)}"
            f"v{f(-(h - 2 * r))}a{f(r)},{f(r)} 0 0 1 {f(r)},{f(-r)}z")


def L(x1, y1, x2, y2):
    return f"M{f(x1)},{f(y1)}L{f(x2)},{f(y2)}"


def P(*pts, close=False):
    s = "M" + "L".join(f"{f(x)},{f(y)}" for x, y in pts)
    return s + ("z" if close else "")


def gear():
    cx = cy = 12.0
    ro, ri = 9.6, 7.3
    pts = []
    for i in range(8):
        t = math.radians(i * 45)
        for a, r in ((-15, ri), (-9, ro), (9, ro), (15, ri)):
            ang = t + math.radians(a)
            pts.append((cx + r * math.cos(ang), cy + r * math.sin(ang)))
    return P(*pts, close=True) + C(12, 12, 3)


# name: (stroke paths, filled paths, autoMirrored)
ICONS = {
    # media + recording (also used by the notification, the tile and the floating control)
    "ic_rec": ([C(12, 12, 8.75)], [C(12, 12, 4.25)], False),
    "ic_stop": ([R(6.5, 6.5, 11, 11, 2.25)], [R(6.5, 6.5, 11, 11, 2.25)], False),
    "ic_pause": ([R(6.5, 5.5, 3.5, 13, 1), R(14, 5.5, 3.5, 13, 1)], [R(6.5, 5.5, 3.5, 13, 1), R(14, 5.5, 3.5, 13, 1)], False),
    "ic_play": ([P((8, 5.5), (18.5, 12), (8, 18.5), close=True)], [P((8, 5.5), (18.5, 12), (8, 18.5), close=True)], False),
    "ic_close": ([L(6.5, 6.5, 17.5, 17.5), L(17.5, 6.5, 6.5, 17.5)], [], False),
    "ic_check": ([P((5, 12.5), (9.75, 17), (19, 7.25))], [], False),
    "ic_check_circle": ([C(12, 12, 9), P((8.25, 12.25), (10.9, 14.9), (15.9, 9.4))], [], False),
    "ic_radio_on": ([C(12, 12, 8.5)], [C(12, 12, 4.5)], False),
    "ic_radio_off": ([C(12, 12, 8.5)], [], False),
    # navigation
    "ic_back": ([L(19, 12, 5, 12), P((11, 6), (5, 12), (11, 18))], [], True),
    "ic_chevron": ([P((9.5, 6), (15.5, 12), (9.5, 18))], [], True),
    "ic_expand": ([P((6, 9.5), (12, 15.5), (18, 9.5))], [], False),
    "ic_more": ([], [C(12, 5.5, 1.6), C(12, 12, 1.6), C(12, 18.5, 1.6)], False),
    "ic_library": ([R(3, 7, 18, 13.5, 3), L(6.5, 3.5, 17.5, 3.5), P((10.25, 10.75), (14.75, 13.75), (10.25, 16.75), close=True)], [], False),
    "ic_quality": ([R(2.75, 5.5, 18.5, 13, 3), L(6.75, 9.25, 6.75, 14.75), L(10.5, 9.25, 10.5, 14.75), L(6.75, 12, 10.5, 12),
                    "M13.75,9.25v5.5h1.6a2.75,2.75 0 0 0 0,-5.5z"], [], False),
    "ic_settings": ([gear()], [], False),
    "ic_info": ([C(12, 12, 9), L(12, 11, 12, 16.25)], [C(12, 7.9, 1.15)], False),
    # actions
    "ic_copy": ([R(8.5, 8.5, 12.5, 12.5, 2.5), "M15.5,8.5V5.5A2.5,2.5 0 0 0 13,3H5.5A2.5,2.5 0 0 0 3,5.5V13A2.5,2.5 0 0 0 5.5,15.5H8.5"], [], False),
    "ic_share": ([C(17.5, 5.5, 2.75), C(6.5, 12, 2.75), C(17.5, 18.5, 2.75), L(8.9, 13.4, 15.1, 17.1), L(15.1, 6.9, 8.9, 10.6)], [], False),
    "ic_delete": ([L(3.5, 6.5, 20.5, 6.5), "M18.5,6.5l-0.85,12.6A2,2 0 0 1 15.66,21H8.34a2,2 0 0 1 -1.99,-1.9L5.5,6.5",
                   "M9,6.5V4.75A1.75,1.75 0 0 1 10.75,3h2.5A1.75,1.75 0 0 1 15,4.75V6.5", L(10, 11, 10, 16.5), L(14, 11, 14, 16.5)], [], False),
    "ic_folder": (["M3,7A2.5,2.5 0 0 1 5.5,4.5h3.7a2,2 0 0 1 1.6,0.8l1.1,1.5a2,2 0 0 0 1.6,0.8h5A2.5,2.5 0 0 1 21,10.1V17.5a2.5,2.5 0 0 1 -2.5,2.5h-13A2.5,2.5 0 0 1 3,17.5z"], [], False),
    "ic_report": ([R(4.75, 4, 14.5, 17.5, 2.5), R(9, 2.5, 6, 3.5, 1.25), L(8.5, 11, 15.5, 11), L(8.5, 14.5, 15.5, 14.5), L(8.5, 18, 12.5, 18)], [], False),
    "ic_bug": ([R(7, 7.5, 10, 13.5, 5), "M9,7.5a3,3 0 0 1 6,0", L(12, 12, 12, 21), L(3, 13.5, 7, 13.5), L(17, 13.5, 21, 13.5),
                L(4, 8.5, 7.4, 10.4), L(20, 8.5, 16.6, 10.4), L(4, 19.5, 7.5, 17.5), L(20, 19.5, 16.5, 17.5)], [], False),
    "ic_alert": (["M10.27,4.4L2.8,17.5A2,2 0 0 0 4.53,20.5h14.94a2,2 0 0 0 1.73,-3L13.73,4.4a2,2 0 0 0 -3.46,0z", L(12, 9.5, 12, 13.5)], [C(12, 16.9, 1.1)], False),
    "ic_lightbulb": ([L(9.25, 18, 14.75, 18), L(10.25, 21.25, 13.75, 21.25),
                      "M12,2.75a6.25,6.25 0 0 0 -3.7,11.3c0.55,0.45 0.95,1.1 0.95,1.85V18h5.5v-2.1c0,-0.75 0.4,-1.4 0.95,-1.85A6.25,6.25 0 0 0 12,2.75z"], [], False),
    "ic_tag": (["M3,4.75v6.1a2,2 0 0 0 0.59,1.41l8.15,8.15a2,2 0 0 0 2.83,0l5.98,-5.98a2,2 0 0 0 0,-2.83L12.4,3.44A2,2 0 0 0 11,2.85H4.9A1.9,1.9 0 0 0 3,4.75z"], [C(7.75, 7.6, 1.35)], False),
    # recording settings
    "ic_tune": ([L(3.5, 6.5, 12.5, 6.5), L(17.5, 6.5, 20.5, 6.5), C(15, 6.5, 2.5), L(3.5, 12, 6.5, 12), L(11.5, 12, 20.5, 12), C(9, 12, 2.5),
                 L(3.5, 17.5, 13.5, 17.5), L(18.5, 17.5, 20.5, 17.5), C(16, 17.5, 2.5)], [], False),
    "ic_bolt": ([P((13, 2.75), (4.75, 13.5), (11.5, 13.5), (10.75, 21.25), (19.25, 10.5), (12.5, 10.5), close=True)], [], False),
    "ic_speed": (["M4.6,17.1A8.5,8.5 0 1 1 19.4,17.1", L(12, 13, 15.75, 9.25)], [C(12, 13, 1.6)], False),
    "ic_leaf": (["M11,20.5A7,7 0 0 1 9.8,6.6C15.5,5.5 17,5 19,2.5c1,2 2,4.2 2,8c0,5.5 -4.8,10 -10,10z",
                 "M3,21.5c0,-3 1.85,-5.35 5.08,-6C10.4,15.05 12.4,13.75 14,11.5"], [], False),
    "ic_resolution": (["M3,8V5.5A2.5,2.5 0 0 1 5.5,3H8", "M16,3h2.5A2.5,2.5 0 0 1 21,5.5V8", "M21,16v2.5A2.5,2.5 0 0 1 18.5,21H16",
                       "M8,21H5.5A2.5,2.5 0 0 1 3,18.5V16", R(8, 8, 8, 8, 1.75)], [], False),
    "ic_bitrate": ([P((2.75, 12), (6.5, 12), (9.5, 19), (14.5, 5), (17.5, 12), (21.25, 12))], [], False),
    "ic_chart": ([L(5.5, 19.5, 5.5, 13), L(12, 19.5, 12, 4.5), L(18.5, 19.5, 18.5, 9)], [], False),
    "ic_memory": ([R(6, 6, 12, 12, 2), R(9.5, 9.5, 5, 5, 1), L(9.5, 2.75, 9.5, 6), L(14.5, 2.75, 14.5, 6), L(9.5, 18, 9.5, 21.25),
                   L(14.5, 18, 14.5, 21.25), L(2.75, 9.5, 6, 9.5), L(2.75, 14.5, 6, 14.5), L(18, 9.5, 21.25, 9.5), L(18, 14.5, 21.25, 14.5)], [], False),
    "ic_movie": ([R(3, 3.5, 18, 17, 2.5), L(7.5, 3.5, 7.5, 20.5), L(16.5, 3.5, 16.5, 20.5), L(3, 12, 21, 12),
                  L(3, 7.75, 7.5, 7.75), L(3, 16.25, 7.5, 16.25), L(16.5, 7.75, 21, 7.75), L(16.5, 16.25, 21, 16.25)], [], False),
    "ic_clock": ([C(12, 12, 9), P((12, 7), (12, 12), (15.25, 14))], [], False),
    "ic_file": (["M14,2.75H7A2.5,2.5 0 0 0 4.5,5.25v13.5A2.5,2.5 0 0 0 7,21.25h10a2.5,2.5 0 0 0 2.5,-2.5V8.25z", P((14, 2.75), (14, 8.25), (19.5, 8.25))], [], False),
    "ic_timer": ([C(12, 13.5, 7.75), L(12, 13.5, 14.75, 10.75), L(10, 2.75, 14, 2.75), L(12, 2.75, 12, 5.75)], [], False),
    "ic_sparkle": (["M11,3.5l1.9,5.1L18,10.5l-5.1,1.9L11,17.5l-1.9,-5.1L4,10.5l5.1,-1.9z", L(18.5, 15, 18.5, 20.5), L(15.75, 17.75, 21.25, 17.75)], [], False),
    # orientation
    "ic_rotate": (["M20.5,12a8.5,8.5 0 0 1 -14.6,5.9L3.5,15.5", P((3.5, 20), (3.5, 15.5), (8, 15.5)),
                   "M3.5,12a8.5,8.5 0 0 1 14.6,-5.9L20.5,8.5", P((20.5, 4), (20.5, 8.5), (16, 8.5))], [], False),
    "ic_portrait": ([R(6.75, 2.75, 10.5, 18.5, 2.5), L(11, 17.75, 13, 17.75)], [], False),
    "ic_landscape": ([R(2.75, 6.75, 18.5, 10.5, 2.5), L(17.75, 11, 17.75, 13)], [], False),
    "ic_gamepad": (["M7.2,7h9.6a4,4 0 0 1 3.9,3.15l1,5a2.75,2.75 0 0 1 -4.9,2.15L15.4,15.5H8.6l-1.4,1.8a2.75,2.75 0 0 1 -4.9,-2.15l1,-5A4,4 0 0 1 7.2,7z",
                    L(8, 9.75, 8, 12.75), L(6.5, 11.25, 9.5, 11.25)], [C(15.5, 10.25, 1.05), C(17.6, 12.35, 1.05)], False),
    # audio
    "ic_volume": ([P((4, 9.5), (7.5, 9.5), (12, 5.5), (12, 18.5), (7.5, 14.5), (4, 14.5), close=True), "M15.5,9.25a3.9,3.9 0 0 1 0,5.5", "M18.25,6.5a7.75,7.75 0 0 1 0,11"], [], False),
    "ic_volume_off": ([P((4, 9.5), (7.5, 9.5), (12, 5.5), (12, 18.5), (7.5, 14.5), (4, 14.5), close=True), L(15.75, 9.75, 20.25, 14.25), L(20.25, 9.75, 15.75, 14.25)], [], False),
    "ic_mic": ([R(9, 2.75, 6, 11.5, 3), "M5.5,11a6.5,6.5 0 0 0 13,0", L(12, 17.5, 12, 21.25), L(9, 21.25, 15, 21.25)], [], False),
    "ic_mic_off": ([R(9, 2.75, 6, 11.5, 3), "M5.5,11a6.5,6.5 0 0 0 13,0", L(12, 17.5, 12, 21.25), L(9, 21.25, 15, 21.25), L(3.5, 3.5, 20.5, 20.5)], [], False),
    "ic_headset": (["M3.75,15v-3a8.25,8.25 0 0 1 16.5,0v3", R(3, 13.5, 4.5, 6.5, 1.75), R(16.5, 13.5, 4.5, 6.5, 1.75), "M18.75,20c0,1.1 -1,1.75 -2.25,1.75H13.5"], [], False),
    # camera + overlays + controls
    "ic_videocam": ([R(2.75, 6, 12.75, 12, 2.5), P((15.5, 10.25), (21.25, 7.25), (21.25, 16.75), (15.5, 13.75), close=True)], [], False),
    "ic_videocam_off": ([R(2.75, 6, 12.75, 12, 2.5), P((15.5, 10.25), (21.25, 7.25), (21.25, 16.75), (15.5, 13.75), close=True), L(3, 3, 21, 21)], [], False),
    "ic_camera": (["M3.25,8.75a2,2 0 0 1 2,-2h2.1l1.6,-2.5h6.1l1.6,2.5h2.1a2,2 0 0 1 2,2v9a2,2 0 0 1 -2,2H5.25a2,2 0 0 1 -2,-2z", C(12, 13, 3.5)], [], False),
    "ic_face": ([C(12, 12, 9), C(12, 10, 3.25), "M6.3,18.6a6.6,6.6 0 0 1 11.4,0"], [], False),
    "ic_layers": ([P((12, 3), (21, 7.5), (12, 12), (3, 7.5), close=True), P((3, 12), (12, 16.5), (21, 12)), P((3, 16.5), (12, 21), (21, 16.5))], [], False),
    "ic_float": ([R(3, 3.5, 18, 17, 3)], [C(15.5, 14, 2.75)], False),
    "ic_overlay": ([R(2.75, 4, 18.5, 16, 3), R(11.5, 11.5, 6.5, 5, 1.25)], [], False),
    "ic_shrink": ([P((4, 14), (10, 14), (10, 20)), P((20, 10), (14, 10), (14, 4)), L(14, 10, 20.5, 3.5), L(3.5, 20.5, 10, 14)], [], False),
    "ic_eye": (["M2.75,12c1,-2.6 4.5,-7 9.25,-7s8.25,4.4 9.25,7c-1,2.6 -4.5,7 -9.25,7s-8.25,-4.4 -9.25,-7z", C(12, 12, 3)], [], False),
    "ic_eye_off": ([L(3.5, 3.5, 20.5, 20.5), "M10.6,5.1A9,9 0 0 1 12,5c4.75,0 8.25,4.4 9.25,7a12.4,12.4 0 0 1 -2.4,3.5",
                    "M6.6,6.6C4.6,8 3.3,10.1 2.75,12c1,2.6 4.5,7 9.25,7a9.3,9.3 0 0 0 5.3,-1.6", "M9.9,9.9a3,3 0 0 0 4.2,4.2"], [], False),
    "ic_vibrate": ([R(8, 4.5, 8, 15, 2), P((2.75, 8.5), (4.75, 10.25), (2.75, 12), (4.75, 13.75), (2.75, 15.5)),
                    P((21.25, 8.5), (19.25, 10.25), (21.25, 12), (19.25, 13.75), (21.25, 15.5))], [], False),
    "ic_bell": (["M6.25,9.75a5.75,5.75 0 0 1 11.5,0c0,5.75 2.5,7.25 2.5,7.25H3.75s2.5,-1.5 2.5,-7.25", "M10.25,20.5a2,2 0 0 0 3.5,0"], [], False),
    "ic_shield": (["M12,21.25s7.5,-3.5 7.5,-9.25V5.75L12,2.75 4.5,5.75V12c0,5.75 7.5,9.25 7.5,9.25z", P((9, 12), (11.1, 14.1), (15.25, 9.9))], [], False),
    "ic_storage": (["M3,13.25l2.55,-6.75A2.25,2.25 0 0 1 7.65,5h8.7a2.25,2.25 0 0 1 2.1,1.5L21,13.25V17.75a2.25,2.25 0 0 1 -2.25,2.25H5.25A2.25,2.25 0 0 1 3,17.75z",
                    L(3, 13.25, 21, 13.25)], [C(7, 16.6, 1.05), C(10.5, 16.6, 1.05)], False),
    "ic_translate": ([L(5, 8, 11, 14), P((4, 14), (10, 8), (12, 5)), L(2.5, 5, 14, 5), L(7, 2.75, 8, 2.75), P((22, 21.25), (17, 11.25), (12, 21.25)), L(13.75, 17.5, 20.25, 17.5)], [], False),
    # the in-app brand mark (same drawing as the launcher icon)
    "ic_logo_mark": ([R(6.75, 2.75, 10.5, 18.5, 3)], [C(12, 12, 2.9)], False),
}


def vector(name, strokes, fills, mirrored):
    out = ['<?xml version="1.0" encoding="utf-8"?>',
           '<!-- RawRec icon set: 24 dp grid, 1.75 stroke, round caps/joins (generated by design/icons.py) -->',
           '<vector xmlns:android="http://schemas.android.com/apk/res/android"',
           '    android:width="24dp"', '    android:height="24dp"']
    if mirrored:
        out.append('    android:autoMirrored="true"')
    out += ['    android:viewportWidth="24"', '    android:viewportHeight="24">']
    if strokes:
        out += ['    <path', f'        android:pathData="{"".join(strokes)}"', '        android:strokeColor="#FFFFFFFF"',
                f'        android:strokeWidth="{SW}"', '        android:strokeLineCap="round"', '        android:strokeLineJoin="round" />']
    if fills:
        out += ['    <path', f'        android:pathData="{"".join(fills)}"', '        android:fillColor="#FFFFFFFF" />']
    out.append('</vector>')
    return "\n".join(out) + "\n"


if __name__ == "__main__":
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "app/src/main/res/drawable")
    for n, (s, fl, m) in ICONS.items():
        with open(os.path.join(d, n + ".xml"), "w") as fh:
            fh.write(vector(n, s, fl, m))
    prev = os.path.join(root, "design/preview.html")
    if os.path.exists(prev):
        html = open(prev, encoding="utf-8").read()
        data = json.dumps({n: [ "".join(s), "".join(fl), m] for n, (s, fl, m) in ICONS.items()}, separators=(",", ":"))
        a, b = "/*ICONS-BEGIN*/", "/*ICONS-END*/"
        if a in html and b in html:
            html = html[:html.index(a) + len(a)] + data + html[html.index(b):]
            open(prev, "w", encoding="utf-8").write(html)
    print(len(ICONS), "icons")
