package com.vil3ntec.rawrec

import android.content.Context
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.random.Random

/**
 * The live chat while streaming: YouTube (read, send, delete, time-out; viewers, likes, subscriber
 * count and new subscribers by name) and Twitch (read only). Runs on its own threads; everything
 * reaches the service through [Listener] (any thread).
 *
 * YouTube's daily allowance (10 000 units, reading the chat costs 5 each time) decides the pace:
 * the chat is read as often as YouTube allows, but never faster than what keeps the allowance for
 * three more hours of streaming, with a reserve kept for the owner's own messages and moderation.
 */
class LiveChat(private val ctx: Context, private val l: Listener) {

    enum class Kind { CHAT, SUPER, MEMBER, GIFT, SUB, CHEER, RAID }
    enum class Platform { YOUTUBE, TWITCH }

    class Msg(
        val id: String, val platform: Platform, val authorId: String, val author: String, val text: String,
        val kind: Kind, val amount: String?, val owner: Boolean, val mod: Boolean, val member: Boolean,
        /** Old messages that were in the chat before RawRec joined: shown, but no alert and no bot. */
        val history: Boolean,
    ) {
        val canModerate: Boolean get() = platform == Platform.YOUTUBE && !owner
    }

    class Stats(val viewers: Long, val likes: Long, val subs: Long)

    /** What the «زنده» page shows about the stream on YouTube. */
    data class YtInfo(
        val videoId: String, val title: String, val thumb: String?, val health: String?,
        /** YouTube's own words: the broadcast's stage (live, testing, ready…), who can watch, whether the picture arrives. */
        val lifeCycle: String = "", val privacy: String = "", val receiving: Boolean? = null,
    )

    interface Listener {
        fun onMessage(m: Msg)
        fun onDeleted(id: String)
        /** A new subscriber; [name] null when only the count went up (subscription not public). */
        fun onSubscriber(name: String?)
        fun onStats(s: Stats)
        /** A short line about the state of each chat, null = fine. */
        fun onState(youtube: String?, twitch: String?)
        /** An action (send, delete, time-out) failed. */
        fun onActionFailed(text: String)
        /** The YouTube stream: found, or its title / health / picture changed. */
        fun onBroadcast(info: YtInfo) {}
        /** Something the owner should know (title or thumbnail set or refused). */
        fun onNote(text: String) {}
    }

    private val yt: YouTubeApi? = LiveExtras.youTube(ctx)
    private val twChannel = LiveExtras.twChannel(ctx)
    val hasYouTube get() = yt != null
    val hasTwitch get() = twChannel.isNotEmpty()

    @Volatile private var running = false
    @Volatile var chatId: String? = null; private set
    @Volatile private var videoId: String? = null
    @Volatile private var bc: YouTubeApi.Broadcast? = null
    @Volatile var ytInfo: YtInfo? = null; private set
    private var health: String? = null
    @Volatile private var ytState: String? = null
    @Volatile private var twState: String? = null
    private var threads = ArrayList<Thread>()
    @Volatile private var twSocket: Socket? = null
    private val actions: ExecutorService = Executors.newSingleThreadExecutor { r -> Thread(r, "rawrec-chat-act") }

    @Volatile var viewers = -1L; private set
    @Volatile var likes = -1L; private set
    @Volatile var subs = -1L; private set
    @Volatile var messages = 0; private set
    @Volatile var newSubs = 0; private set

    /** True when messages can be sent (YouTube chat found). */
    val canSend: Boolean get() = yt != null && chatId != null

    fun start() {
        if (running) return
        running = true
        if (yt != null) { ytState = ctx.getString(R.string.chat_yt_looking); threads += Thread({ ytLoop(yt) }, "rawrec-chat-yt").apply { start() } }
        if (twChannel.isNotEmpty()) { twState = ctx.getString(R.string.chat_tw_joining); threads += Thread({ twLoop() }, "rawrec-chat-tw").apply { start() } }
        state()
    }

    fun stop() {
        running = false
        // a live made here that never went out stays no «Upcoming» on the channel
        val made = createdId
        val api = yt
        if (made != null && !wentLive && api != null) Thread({
            try { if (api.deleteIfNeverLive(made)) LiveExtras.setMadeLive(ctx, made, false) } catch (_: Exception) {}
        }, "rawrec-yt-tidy").start()
        try { twSocket?.close() } catch (_: Exception) {}
        for (t in threads) t.interrupt()
        threads.clear()
        actions.shutdownNow()
    }

    // ------------------------------------------------------------ actions (YouTube)

    fun send(text: String) {
        val api = yt ?: return
        val chat = chatId ?: return
        val t = text.trim().take(200)
        if (t.isEmpty()) return
        act(R.string.chat_f_send, 20) { api.send(chat, t) }
    }

    fun delete(m: Msg) {
        val api = yt ?: return
        if (!m.canModerate || m.id.isEmpty()) return
        act(R.string.chat_f_delete, 20) { api.delete(m.id) }
    }

    /** [seconds] 0 = ban for good. */
    fun timeout(m: Msg, seconds: Int) {
        val api = yt ?: return
        val chat = chatId ?: return
        if (!m.canModerate || m.authorId.isEmpty()) return
        act(R.string.chat_f_ban, 200) { api.ban(chat, m.authorId, seconds) }
    }

    /** For the bot's time-outs, by channel id. */
    fun timeout(authorId: String, seconds: Int) {
        val api = yt ?: return
        val chat = chatId ?: return
        act(R.string.chat_f_ban, 200) { api.ban(chat, authorId, seconds) }
    }

    fun deleteId(id: String) {
        val api = yt ?: return
        act(R.string.chat_f_delete, 20) { api.delete(id) }
    }

    private fun act(what: Int, units: Int, block: () -> Unit) {
        if (LiveExtras.Quota.left(ctx) < units) { l.onActionFailed(ctx.getString(R.string.chat_quota_out)); return }
        try {
            actions.execute {
                try { block() } catch (e: YouTubeApi.Companion.HttpError) {
                    if (quotaGone(e)) LiveExtras.Quota.exhaust(ctx)
                    l.onActionFailed(ctx.getString(what) + " — " + friendly(e))
                } catch (e: Exception) {
                    l.onActionFailed(ctx.getString(what) + " — " + (e.message ?: e.javaClass.simpleName))
                }
            }
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ YouTube

    private fun ytLoop(api: YouTubeApi) {
        var page: String? = null
        var first = true
        var nextStats = 0L
        var nextSubs = 0L
        val startedAt = System.currentTimeMillis()
        var knownSubs: HashSet<String>? = null
        var maxSubs = -1L
        while (running) {
            try {
                if (LiveExtras.Quota.left(ctx) < RESERVE) {
                    setYt(ctx.getString(R.string.chat_quota_out))
                    // the chat waits for tomorrow's allowance; going live does not (a few units, once)
                    rest(api, 60_000); continue
                }
                // which of the channel's streams takes our key (once; the broadcast is the one bound to it)
                if (streamId == null && System.currentTimeMillis() - streamTried > 60_000) {
                    streamTried = System.currentTimeMillis()
                    streamId = try { api.streamIdForKey(ourKey()) } catch (e: YouTubeApi.Companion.HttpError) { if (quotaGone(e)) throw e; null }
                    RecLog.add(ctx, "yt: stream " + (streamId ?: "not found for the key"))
                }
                // once a stream: only one live waits on our key (several = YouTube may start one and show another)
                streamId?.let { sid -> if (!tidied) { tidied = true; tidy(api, sid) } }
                val waiting = bc?.let { !it.isLive } ?: false
                // waiting to go live: the channel is looked at again every 15 s (the live itself is driven below, more often)
                if (chatId == null || (waiting && System.currentTimeMillis() - lastLook > 15_000)) {
                    lastLook = System.currentTimeMillis()
                    val b = api.currentBroadcast(streamId)
                    if (b == null) {
                        val sid = streamId
                        val waited = System.currentTimeMillis() - startedAt
                        // YouTube itself sets up the Studio live for the key a moment after the picture arrives: 20 s of
                        // picture with nothing bound before one is made here (as streaming apps do)
                        // with Shorts the live is the one set up in Studio («Dual stream»): never another one made
                        val active = sid != null && !created && !LiveSettings.shortsReady(ctx) &&
                            (try { api.streamStatus(sid).first } catch (_: Exception) { "" }) == "active"
                        if (!active) activeSince = 0L
                        else if (activeSince == 0L) { activeSince = System.currentTimeMillis(); RecLog.add(ctx, "yt: stream active, nothing bound to it") }
                        when {
                            sid != null && !created && activeSince != 0L && System.currentTimeMillis() - activeSince >= 20_000 -> {
                                created = true
                                try {
                                    createdId = api.createBroadcast(sid, LiveExtras.ytTitle(ctx).ifBlank { ctx.getString(R.string.yt_default_title_fmt, LiveExtras.ytChannel(ctx).ifBlank { "Live" }) },
                                        LiveExtras.ytDesc(ctx), LiveExtras.ytPrivacyToSet(ctx).ifEmpty { "public" }, LiveExtras.ytKidsToSet(ctx) ?: false,
                                        autoStart = LiveExtras.goLiveNow(ctx))
                                    createdId?.let { LiveExtras.setMadeLive(ctx, it, true); RecLog.add(ctx, "yt: made $it") }
                                    l.onNote(ctx.getString(R.string.yt_created))
                                    lastLook = 0L
                                    sleep(3_000); continue
                                } catch (e: YouTubeApi.Companion.HttpError) {
                                    if (quotaGone(e)) throw e
                                    l.onNote(ctx.getString(R.string.yt_create_failed_fmt, friendly(e)))
                                }
                            }
                            // our key is not one of this channel's streams: said plainly
                            sid == null && streamTried > 0 && waited > 15_000 -> setYt(ctx.getString(R.string.chat_yt_no_key))
                            // a stream, nothing bound: said whether the picture is there yet, and that a live is coming
                            sid != null && !created && !LiveSettings.shortsReady(ctx) ->
                                setYt(ctx.getString(if (activeSince != 0L) R.string.chat_yt_making_soon else R.string.chat_yt_no_picture))
                            else -> setYt(ctx.getString(R.string.chat_yt_looking))
                        }
                        sleep(if (waited < 120_000) 10_000 else 30_000); continue
                    }
                    if (b.videoId != bc?.videoId) {
                        chatId = b.chatId.ifBlank { null }; videoId = b.videoId
                        page = null; first = true
                        appliedStamp = ""
                    }
                    bc = b
                    if (b.isLive) setYt(null)
                    publish()
                    if (b.videoId != usingLogged) { usingLogged = b.videoId; RecLog.add(ctx, "yt: using ${b.videoId} (${b.lifeCycle})") }
                    if (b.isLive && !wentLive) { wentLive = true; LiveExtras.setMadeLive(ctx, b.videoId, false); RecLog.add(ctx, "yt: ${b.videoId} live") }
                    if (LiveExtras.ytChoicesStamp(ctx) != appliedStamp) applyOwnerChoices(api, b)
                }
                // held back by YouTube: put live step by step, and kept at until it is (at its own pace)
                bc?.let { b -> if (!b.isLive) goLiveIfWaiting(api, b) }
                if (chatId == null) { rest(api, 10_000); continue }   // (a broadcast without its chat yet)
                // the owner changed the video's settings in the app while live: applied at once
                bc?.let { b -> if (LiveExtras.ytChoicesStamp(ctx) != appliedStamp) applyOwnerChoices(api, b) }
                val now = System.currentTimeMillis()
                if (now >= nextStats) {
                    nextStats = now + 30_000
                    videoId?.let { v -> val (a, b) = api.videoStats(v); viewers = a; likes = b }
                    l.onStats(Stats(viewers, likes, subs))
                    bc?.streamId?.let { sid ->
                        val (st, h) = try { api.streamStatus(sid) } catch (_: Exception) { "" to null }
                        val rec = if (st.isEmpty()) null else st == "active"
                        if (h != health || rec != receiving) { health = h; receiving = rec; publish() }
                    }
                }
                if (now >= nextSubs) {
                    nextSubs = now + 60_000
                    val count = api.subscriberCount()
                    val recent = api.recentSubscribers()
                    var named = 0
                    val known = knownSubs
                    if (known == null) knownSubs = recent.map { it.channelId }.toHashSet()
                    else for (s in recent.reversed()) if (known.add(s.channelId)) { named++; newSubs++; l.onSubscriber(s.name) }
                    // Small channels: YouTube gives the exact count, so a rise without a public name is still thanked.
                    if (maxSubs in 0 until count && count < 1000 && named == 0) {
                        repeat(((count - maxSubs).toInt()).coerceAtMost(3)) { newSubs++; l.onSubscriber(null) }
                    }
                    if (count > maxSubs) maxSubs = count
                    subs = count
                    l.onStats(Stats(viewers, likes, subs))
                }
                val chat = chatId ?: continue
                val p = api.chat(chat, page)
                page = p.next
                for (it in p.items) dispatch(it, first)
                first = false
                rest(api, pace(p.pollMs))
            } catch (e: YouTubeApi.Companion.HttpError) {
                when {
                    quotaGone(e) -> { LiveExtras.Quota.exhaust(ctx); setYt(ctx.getString(R.string.chat_quota_out)) }
                    e.reason in listOf("liveChatEnded", "liveChatNotFound", "liveChatDisabled") -> {
                        chatId = null; page = null; first = true
                        setYt(ctx.getString(R.string.chat_yt_ended))
                    }
                    e.body.contains("invalid_grant") -> {
                        setYt(ctx.getString(R.string.chat_yt_signin_again))
                        LiveExtras.setYtToken(ctx, null)
                        return
                    }
                    e.reason == "rateLimitExceeded" -> {}
                    else -> setYt(ctx.getString(R.string.chat_yt_error_fmt, friendly(e)))
                }
                sleep(30_000)
            } catch (_: InterruptedException) {
                return
            } catch (e: IOException) {
                setYt(ctx.getString(R.string.chat_net))
                sleep(10_000)
            } catch (e: Exception) {
                setYt(ctx.getString(R.string.chat_yt_error_fmt, e.message ?: e.javaClass.simpleName))
                sleep(30_000)
            }
        }
    }

    private var streamId: String? = null
    @Volatile private var receiving: Boolean? = null
    private var streamTried = 0L
    private var lastLook = 0L
    /** Since when the stream has been active with nothing bound to it (0 = not so). */
    private var activeSince = 0L
    private var nextGoLive = 0L
    private var goLiveFails = 0
    /** After «invalidTransition»: the other way round (ready → live when a monitor was assumed, or testing when none). */
    private var flip = false
    private var autoStartTried = ""
    private var toldStudio = false
    private var tidied = false
    private var usingLogged = ""
    private var lastStreamStatus = ""

    /**
     * Several lives waiting on our key: the ones this app made and that never went live are taken off
     * the channel; of the owner's own, the one meant for now (nearest by its time) stays bound and the
     * others are only unbound (kept on the channel, untouched). Then the stream feeds exactly one
     * live, the one shown and put live.
     */
    private fun tidy(api: YouTubeApi, sid: String) {
        try {
            val list = api.boundTo(sid)
            if (list.any { it.isLive }) return
            val waiting = list.filter { it.lifeCycle in setOf("created", "ready", "testStarting", "testing") }
            // the live made for this very stream (the app's own) is the one kept, always; never taken off here
            val ours = createdId
            if (waiting.size < 2 && waiting.none { it.videoId in LiveExtras.madeLives(ctx) && it.videoId != ours }) return
            val made = LiveExtras.madeLives(ctx) - setOfNotNull(ours)
            val keep = waiting.firstOrNull { it.videoId == ours }
                ?: GoLive.nearest(waiting.filter { it.videoId !in made }, { it.scheduled }, System.currentTimeMillis())
            var gone = 0; var loose = 0
            for (o in waiting) if (o.videoId != keep?.videoId) {
                if (o.videoId in made) { if (api.deleteIfNeverLive(o.videoId)) gone++; LiveExtras.setMadeLive(ctx, o.videoId, false) }
                else { api.unbind(o.videoId); loose++ }
            }
            RecLog.add(ctx, "yt: tidied — $gone made here taken off, $loose unbound, kept ${keep?.videoId ?: "none"}")
        } catch (e: Exception) { RecLog.add(ctx, "yt: tidy failed: " + (e.message ?: "")) }
    }
    /** The live this app made for this stream, and whether it went live (else it is taken off at the end). */
    @Volatile private var createdId: String? = null
    @Volatile private var wentLive = false
    /** A live was made on the channel for this stream (once). */
    private var created = false

    private var ownKey: String? = null
    /** This stream goes to the app's own stream on the channel, with the live made for it just now. */
    fun ownLive(streamId: String, key: String, broadcastId: String) {
        this.streamId = streamId; ownKey = key; created = true; createdId = broadcastId
    }

    /** The YouTube stream key this stream is sent with (the app's own, else the platform switched on with a YouTube address). */
    private fun ourKey(): String = ownKey ?: LiveExtras.sessionKey
        ?: LiveSettings.destinations(ctx).firstOrNull { it.url.contains("youtube", ignoreCase = true) }?.key ?: LiveSettings.key(ctx, 0)

    /**
     * YouTube holds the live back while the picture arrives (Studio's preview, «Go live» not pressed, a
     * live made a moment ago): it is put live step by step — bound if loose, testing first when it has
     * a monitor, then live — and kept at until YouTube says live, for as long as the stream runs. Each
     * step reads the live afresh; a refusal is tried again later (5 s … 5 min), never given up on.
     * First, once, YouTube is asked to start it by itself when the picture arrives (Studio keeps that
     * setting for the next lives on the key too).
     */
    private fun goLiveIfWaiting(api: YouTubeApi, b: YouTubeApi.Broadcast) {
        // the owner goes live in Studio: nothing done here but saying so once
        if (!LiveExtras.goLiveNow(ctx)) { if (!toldStudio) { toldStudio = true; l.onNote(ctx.getString(R.string.yt_go_live_studio)) }; return }
        val sid = b.streamId ?: streamId ?: return
        val now = System.currentTimeMillis()
        if (now < nextGoLive) return
        nextGoLive = now + 5_000
        if (!b.autoStart && autoStartTried != b.videoId) {
            autoStartTried = b.videoId
            try { if (api.setAutoStart(b.videoId)) RecLog.add(ctx, "yt: ${b.videoId} auto-start on") }
            catch (e: Exception) { RecLog.add(ctx, "yt: auto-start refused: " + why(e)) }
        }
        val (status, _) = try { api.streamStatus(sid) } catch (_: Exception) { "" to null }
        if (status != lastStreamStatus) { lastStreamStatus = status; RecLog.add(ctx, "yt: stream ${status.ifEmpty { "?" }}, live ${b.videoId} ${b.lifeCycle}") }
        if (status != "active") { setYt(ctx.getString(R.string.chat_yt_no_picture)); return }   // the picture is not there yet
        // the live as it is now, not as read a while ago
        val cur = (try { api.broadcast(b.videoId) } catch (_: Exception) { null }) ?: b
        if (cur.lifeCycle != b.lifeCycle) { bc = cur; publish(); RecLog.add(ctx, "yt: ${cur.videoId} ${cur.lifeCycle}") }
        if (cur.isLive) { nowLive(cur, false); return }
        setYt(ctx.getString(R.string.chat_yt_going_live))
        val step = GoLive.step(cur.lifeCycle, cur.monitor, flip)
        if (step == null) { nextGoLive = now + 3_000; return }   // between stages (testStarting / liveStarting): a moment
        try {
            if (step == GoLive.BIND) api.bind(cur.videoId, sid) else api.transition(cur.videoId, step)
            RecLog.add(ctx, "yt: ${cur.videoId} ${cur.lifeCycle} → $step")
            goLiveFails = 0; nextGoLive = now + 3_000
            if (step == GoLive.LIVE) nowLive(cur, true)
        } catch (e: Exception) {
            val reason = (e as? YouTubeApi.Companion.HttpError)?.reason ?: ""
            RecLog.add(ctx, "yt: $step refused: " + why(e))
            if (reason == "redundantTransition") { nextGoLive = now + 3_000; return }   // already there
            if (reason == "invalidTransition") flip = !flip
            goLiveFails++
            nextGoLive = now + GoLive.retryMs(goLiveFails, reason)
            setYt(ctx.getString(R.string.chat_yt_held_fmt, why(e)))
            if (goLiveFails == 5) l.onNote(ctx.getString(R.string.yt_waiting_fmt, why(e)))
        }
    }

    /** YouTube says live (or took our word for it): shown so; [byUs] = the app put it live. */
    private fun nowLive(b: YouTubeApi.Broadcast, byUs: Boolean) {
        setYt(null)
        if (wentLive) return
        wentLive = true; LiveExtras.setMadeLive(ctx, b.videoId, false)
        RecLog.add(ctx, "yt: ${b.videoId} live" + if (byUs) " (put live here)" else "")
        if (byUs) l.onNote(ctx.getString(R.string.yt_went_live))
    }

    private fun why(e: Exception) = (e as? YouTubeApi.Companion.HttpError)?.let { friendly(it) } ?: e.message ?: e.javaClass.simpleName

    /** Sleeps [ms]; while a live waits to go live, it is looked after every 5 s meanwhile. */
    private fun rest(api: YouTubeApi, ms: Long) {
        var left = ms
        while (left > 0 && running) {
            val b = bc
            if (b == null || b.isLive) { sleep(left); return }
            val s = minOf(left, 5_000L)
            if (!sleep(s)) return
            left -= s
            bc?.let { if (!it.isLive) goLiveIfWaiting(api, it) }
        }
    }

    private fun publish() {
        val b = bc ?: return
        ytInfo = YtInfo(b.videoId, b.title, b.thumb, health, b.lifeCycle, b.privacy, receiving)
        l.onBroadcast(ytInfo!!)
    }

    private var appliedStamp = ""

    /**
     * What the owner chose for the video in the app (title, description, who can watch it, «made for
     * kids», category, tags, embedding) on the video itself, and the thumbnail. YouTube is read first
     * and only what differs is sent; once per stream, and again when the owner changes it while live.
     */
    private fun applyOwnerChoices(api: YouTubeApi, b: YouTubeApi.Broadcast) {
        val p = ctx.getSharedPreferences(RecordService.PREFS, Context.MODE_PRIVATE)
        appliedStamp = LiveExtras.ytChoicesStamp(ctx)
        val want = YouTubeApi.VideoChange(
            title = LiveExtras.ytTitle(ctx).ifBlank { null },
            description = LiveExtras.ytDesc(ctx).ifBlank { null },
            privacy = LiveExtras.ytPrivacyToSet(ctx).ifEmpty { null },
            kids = LiveExtras.ytKidsToSet(ctx),
            category = LiveExtras.ytCategory(ctx).ifBlank { null },
            tags = LiveExtras.ytTags(ctx).takeIf { it.isNotEmpty() },
            embeddable = when (LiveExtras.ytEmbed(ctx)) { "yes" -> true; "no" -> false; else -> null },
        )
        if (listOf(want.title, want.description, want.privacy, want.kids, want.category, want.tags, want.embeddable).any { it != null }) {
            try {
                val changed = api.updateVideo(b.videoId, want)
                if ("title" in changed) {
                    bc = YouTubeApi.Broadcast(b.videoId, b.chatId, want.title!!, b.thumb, b.streamId, b.scheduled, b.description, b.privacy, b.kids, b.lifeCycle, b.autoStart, b.monitor)
                    publish()
                    l.onNote(ctx.getString(R.string.yt_title_set_fmt, want.title))
                }
                if ("privacy" in changed) l.onNote(ctx.getString(R.string.yt_privacy_set_fmt, ctx.getString(when (want.privacy) {
                    "unlisted" -> R.string.yt_p_unlisted; "private" -> R.string.yt_p_private; else -> R.string.yt_p_public })))
                if (changed.any { it != "title" && it != "privacy" }) l.onNote(ctx.getString(R.string.yt_settings_set))
            } catch (e: Exception) {
                l.onNote(ctx.getString(R.string.yt_video_failed_fmt, (e as? YouTubeApi.Companion.HttpError)?.let { friendly(it) } ?: e.message ?: ""))
            }
        }
        val thumb = LiveExtras.ytThumbFile(ctx)
        val stamp = "${b.videoId}:${thumb?.lastModified()}"
        if (thumb != null && SafePrefs.str(p, "yt_thumb_done") != stamp) {
            try {
                api.setThumbnail(b.videoId, thumb.readBytes())
                p.edit().putString("yt_thumb_done", stamp).apply()
                l.onNote(ctx.getString(R.string.yt_thumb_set))
            } catch (e: Exception) {
                val why = (e as? YouTubeApi.Companion.HttpError)?.let { if (it.code == 403) ctx.getString(R.string.yt_thumb_verify) else friendly(it) } ?: e.message ?: ""
                l.onNote(ctx.getString(R.string.yt_thumb_failed_fmt, why))
            }
        }
    }

    /** As often as YouTube asks, but slow enough that the allowance lasts [HORIZON_S] more seconds. */
    private fun pace(serverMs: Long): Long {
        val left = (LiveExtras.Quota.left(ctx) - RESERVE).coerceAtLeast(1)
        val needMs = 5L * HORIZON_S * 1000 / left
        return maxOf(serverMs, needMs).coerceIn(2_000, 60_000)
    }

    private fun dispatch(c: YouTubeApi.ChatItem, history: Boolean) {
        val kind = when (c.type) {
            "textMessageEvent" -> Kind.CHAT
            "superChatEvent", "superStickerEvent" -> Kind.SUPER
            "newSponsorEvent", "memberMilestoneChatEvent" -> Kind.MEMBER
            "membershipGiftingEvent" -> Kind.GIFT
            "messageDeletedEvent" -> { c.deletedId?.let { l.onDeleted(it) }; return }
            "chatEndedEvent" -> { chatId = null; setYt(ctx.getString(R.string.chat_yt_ended)); return }
            else -> return
        }
        val amount = when (kind) { Kind.SUPER -> c.amount; Kind.MEMBER -> c.tier; Kind.GIFT -> c.gifts.toString(); else -> null }
        messages++
        l.onMessage(Msg(c.id, Platform.YOUTUBE, c.authorId, c.author, c.text, kind, amount, c.isOwner, c.isMod, c.isMember, history))
    }

    private fun setYt(s: String?) { if (ytState != s) { ytState = s; state() } }
    private fun setTw(s: String?) { if (twState != s) { twState = s; state() } }
    private fun state() = l.onState(if (yt != null) ytState else null, if (twChannel.isNotEmpty()) twState else null)

    // ------------------------------------------------------------ Twitch (read only)

    private fun twLoop() {
        var backoff = 2_000L
        while (running) {
            var sock: SSLSocket? = null
            try {
                val raw = Socket()
                raw.connect(InetSocketAddress(TwitchIrc.HOST, TwitchIrc.PORT), 10_000)
                sock = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(raw, TwitchIrc.HOST, TwitchIrc.PORT, true) as SSLSocket
                sock.sslParameters = sock.sslParameters.apply { endpointIdentificationAlgorithm = "HTTPS" }
                sock.soTimeout = 400_000   // Twitch pings about every five minutes
                sock.startHandshake()
                twSocket = sock
                val out = sock.outputStream
                write(out, TwitchIrc.hello(twChannel, 10_000 + Random.nextInt(89_999)))
                val rd = BufferedReader(InputStreamReader(sock.inputStream, Charsets.UTF_8))
                var first = true
                while (running) {
                    val line = rd.readLine() ?: break
                    val ev = TwitchIrc.parse(line)?.let { TwitchIrc.event(it) } ?: continue
                    when (ev) {
                        is TwitchIrc.Ev.Ping -> write(out, "PONG :${ev.arg}\r\n")
                        is TwitchIrc.Ev.Reconnect -> break
                        is TwitchIrc.Ev.Joined -> { setTw(null); backoff = 2_000L; first = false }
                        is TwitchIrc.Ev.Notice -> if (ev.id.startsWith("msg_channel_suspended") || ev.id == "msg_banned")
                            setTw(ctx.getString(R.string.chat_tw_problem_fmt, ev.text))
                        is TwitchIrc.Ev.Deleted -> l.onDeleted(ev.id)
                        is TwitchIrc.Ev.Msg -> {
                            val kind = when (ev.kind) { "cheer" -> Kind.CHEER; "sub" -> Kind.SUB; "gift" -> Kind.GIFT; "raid" -> Kind.RAID; else -> Kind.CHAT }
                            messages++
                            l.onMessage(Msg(ev.id, Platform.TWITCH, ev.authorId, ev.author, ev.text, kind, ev.amount, ev.owner, ev.mod, ev.member, first))
                        }
                    }
                }
            } catch (_: InterruptedException) {
                return
            } catch (_: Exception) {
                if (!running) return
                setTw(ctx.getString(R.string.chat_net))
            } finally {
                try { sock?.close() } catch (_: Exception) {}
                twSocket = null
            }
            if (!running) return
            if (!sleep(backoff)) return
            backoff = (backoff * 2).coerceAtMost(60_000)
        }
    }

    private fun write(out: OutputStream, s: String) { out.write(s.toByteArray(Charsets.UTF_8)); out.flush() }

    /** False when interrupted (stopping). */
    private fun sleep(ms: Long): Boolean = try { Thread.sleep(ms); true } catch (_: InterruptedException) { running = false; false }

    private fun quotaGone(e: YouTubeApi.Companion.HttpError) = e.reason == "quotaExceeded" || e.reason == "dailyLimitExceeded"

    private fun friendly(e: YouTubeApi.Companion.HttpError): String = when {
        e.reason == "forbidden" || e.reason == "insufficientPermissions" -> ctx.getString(R.string.chat_e_forbidden)
        quotaGone(e) -> ctx.getString(R.string.chat_quota_out)
        e.reason.isNotEmpty() -> e.reason
        else -> "HTTP ${e.code}"
    }

    companion object {
        /** Units kept back for the owner's messages and moderation. */
        const val RESERVE = 600
        /** The allowance is spread over this many more seconds of streaming. */
        const val HORIZON_S = 3 * 3600L
    }
}

/** The steps that take a live YouTube holds back to live, and how soon to try again when one is refused. */
internal object GoLive {
    const val BIND = "bind"; const val TESTING = "testing"; const val LIVE = "live"

    /**
     * What to ask next for a live at [lifeCycle]: bound when loose (created), testing first when it has
     * a monitor (Studio's preview; [flip] = the other way, after YouTube said «invalidTransition»), live
     * from testing; nothing while YouTube is between stages (testStarting, liveStarting) or it is over.
     */
    fun step(lifeCycle: String, monitor: Boolean, flip: Boolean = false): String? = when (lifeCycle) {
        "created" -> BIND
        "ready" -> if (monitor != flip) TESTING else LIVE
        "testing" -> LIVE
        else -> null
    }

    /** After [fails] refusals in a row: 5 s, 10, 20, 40, then a minute; after ten, or with no right to do it, five minutes. */
    fun retryMs(fails: Int, reason: String = ""): Long = when {
        reason == "forbidden" || reason == "insufficientPermissions" || fails >= 10 -> 300_000L
        else -> (5_000L shl (fails - 1).coerceIn(0, 4)).coerceAtMost(60_000L)
    }

    /** Of the owner's waiting lives, the one meant for now: nearest to [nowMs] by its time (an event for next week stays as it is). */
    fun <T> nearest(list: List<T>, scheduled: (T) -> String?, nowMs: Long): T? =
        list.minByOrNull { t -> scheduled(t)?.let { parse(it) }?.let { kotlin.math.abs(it - nowMs) } ?: Long.MAX_VALUE }

    /** YouTube's «2026-11-09T02:12:00Z» (or with fractions) to ms; null for anything else. */
    fun parse(iso: String): Long? {
        val m = Regex("""(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)""").find(iso) ?: return null
        val (y, mo, d, h, mi, sec) = m.destructured
        return java.util.GregorianCalendar(java.util.TimeZone.getTimeZone("UTC")).apply {
            clear(); set(y.toInt(), mo.toInt() - 1, d.toInt(), h.toInt(), mi.toInt(), sec.toInt())
        }.timeInMillis
    }
}
